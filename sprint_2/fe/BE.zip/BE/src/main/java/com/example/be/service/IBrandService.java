package com.example.be.service;

import com.example.be.model.Brand;

import java.util.List;

public interface IBrandService {
    List<Brand> findAll();
}
