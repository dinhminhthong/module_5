package com.example.be.service;

import com.example.be.model.ProductType;

import java.util.List;

public interface IProductTypeService {
    List<ProductType> findAll();
}
